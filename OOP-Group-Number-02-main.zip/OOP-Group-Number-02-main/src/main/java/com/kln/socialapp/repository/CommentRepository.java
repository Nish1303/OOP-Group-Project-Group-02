package com.kln.socialapp.repository;

import com.kln.socialapp.entity.Comment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CommentRepository extends JpaRepository<Comment, Long> {

    List<Comment> findByPostIdOrderByCreatedAtAsc(Long postId);

    long countByPostId(Long postId);

    Optional<Comment> findByIdAndAuthorId(Long id, Long authorId);
}
