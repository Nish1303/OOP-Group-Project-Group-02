package com.kln.socialapp.controller;

import com.kln.socialapp.entity.User;
import com.kln.socialapp.service.AdminService;
import com.kln.socialapp.service.PostService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/**
 * Admin-only controller. Spring Security ensures only ROLE_ADMIN users can
 * reach any /admin/** path (see SecurityConfig). All other users get 403.
 */
@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

    private final AdminService adminService;
    private final PostService postService;

    @GetMapping
    public String dashboard(Model model,
                             @RequestParam(defaultValue = "0") int page) {
        Page<User> users = adminService.getAllUsers(page, 15);
        model.addAttribute("users", users);
        model.addAttribute("totalUsers", adminService.countUsers());
        model.addAttribute("totalPosts", adminService.countPosts());
        return "admin/dashboard";
    }

    @PostMapping("/users/{userId}/toggle")
    public String toggleUser(@PathVariable Long userId) {
        adminService.toggleUserEnabled(userId);
        return "redirect:/admin";
    }

    @PostMapping("/posts/{postId}/delete")
    public String deletePost(@PathVariable Long postId) {
        adminService.deletePost(postId);
        return "redirect:/admin";
    }
}
