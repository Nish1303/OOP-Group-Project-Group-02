package com.kln.socialapp.controller;

import com.kln.socialapp.dto.PostDto;
import com.kln.socialapp.entity.User;
import com.kln.socialapp.service.PostService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * Handles the authenticated Home Feed page and post creation.
 */
@Controller
@RequiredArgsConstructor
public class FeedController {

    private final PostService postService;

    @GetMapping("/feed")
    public String feed(@AuthenticationPrincipal User currentUser, Model model) {
        model.addAttribute("posts", postService.getFeedForUser(currentUser));
        if (!model.containsAttribute("postDto")) {
            model.addAttribute("postDto", new PostDto());
        }
        model.addAttribute("currentUser", currentUser);
        return "feed";
    }

    @PostMapping("/posts")
    public String createPost(@AuthenticationPrincipal User currentUser,
                              @Valid @ModelAttribute("postDto") PostDto postDto,
                              BindingResult bindingResult,
                              Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("posts", postService.getFeedForUser(currentUser));
            model.addAttribute("currentUser", currentUser);
            return "feed";
        }

        postService.createPost(currentUser, postDto);
        return "redirect:/feed";
    }
}
