package com.kln.socialapp.exception;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * Centralised, graceful error handling so no unhandled exception is ever shown
 * directly to the end user (Technical Requirement: Validation & Error Handling).
 *
 * Page-rendering controllers get a friendly Thymeleaf error view; REST/AJAX
 * endpoints (like the like/unlike API) get a JSON error response instead.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(IllegalArgumentException.class)
    public String handleIllegalArgument(IllegalArgumentException ex, Model model) {
        model.addAttribute("errorMessage", ex.getMessage());
        return "error";
    }

    @ExceptionHandler(FriendRequestException.class)
    public String handleFriendRequest(FriendRequestException ex, Model model) {
        model.addAttribute("errorMessage", ex.getMessage());
        return "error";
    }

    @ExceptionHandler(Exception.class)
    public String handleGenericException(Exception ex, Model model) {
        model.addAttribute("errorMessage", "Something went wrong. Please try again.");
        return "error";
    }
}
