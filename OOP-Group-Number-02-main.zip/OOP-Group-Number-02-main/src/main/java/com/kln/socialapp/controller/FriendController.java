package com.kln.socialapp.controller;

import com.kln.socialapp.entity.User;
import com.kln.socialapp.service.FriendService;
import com.kln.socialapp.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Handles the User Directory and the Friend Request system
 * (send / accept / decline / view incoming & outgoing).
 */
@Controller
@RequiredArgsConstructor
public class FriendController {

    private final UserService userService;
    private final FriendService friendService;

    @GetMapping("/directory")
    public String directory(@AuthenticationPrincipal User currentUser,
                             @RequestParam(defaultValue = "0") int page,
                             @RequestParam(required = false) String q,
                             Model model) {
        int size = 10;
        Page<User> users = (q != null && !q.isBlank())
                ? userService.searchUsers(currentUser.getId(), q.trim(), page, size)
                : userService.getDirectory(currentUser.getId(), page, size);

        Map<Long, String> relationshipStatuses = new HashMap<>();
        for (User u : users.getContent()) {
            relationshipStatuses.put(u.getId(), friendService.getRelationshipStatus(currentUser.getId(), u.getId()));
        }

        model.addAttribute("users", users);
        model.addAttribute("relationshipStatuses", relationshipStatuses);
        model.addAttribute("query", q);
        return "directory";
    }

    @PostMapping("/friends/request/{userId}")
    public String sendRequest(@AuthenticationPrincipal User currentUser, @PathVariable Long userId) {
        friendService.sendRequest(currentUser, userId);
        return "redirect:/directory";
    }

    @GetMapping("/friends")
    public String friendsHome(@AuthenticationPrincipal User currentUser, Model model) {
        model.addAttribute("incoming", friendService.getIncomingRequests(currentUser.getId()));
        model.addAttribute("outgoing", friendService.getOutgoingRequests(currentUser.getId()));
        model.addAttribute("friends", friendService.getFriends(currentUser.getId()));
        model.addAttribute("currentUserId", currentUser.getId());
        return "friends";
    }

    @PostMapping("/friends/requests/{requestId}/accept")
    public String acceptRequest(@AuthenticationPrincipal User currentUser, @PathVariable Long requestId) {
        friendService.respondToRequest(requestId, currentUser, true);
        return "redirect:/friends";
    }

    @PostMapping("/friends/requests/{requestId}/decline")
    public String declineRequest(@AuthenticationPrincipal User currentUser, @PathVariable Long requestId) {
        friendService.respondToRequest(requestId, currentUser, false);
        return "redirect:/friends";
    }
}
