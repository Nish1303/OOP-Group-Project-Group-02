package com.kln.socialapp.controller;

import com.kln.socialapp.dto.ProfileUpdateDto;
import com.kln.socialapp.entity.User;
import com.kln.socialapp.repository.PostRepository;
import com.kln.socialapp.service.ProfileService;
import com.kln.socialapp.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

/**
 * Optional User Profile Page feature (5%).
 * Shows a user's profile, their posts, post count, friend count, and bio.
 * /profile      → own profile (view + edit)
 * /profile/{id} → another user's profile (view only)
 */
@Controller
@RequiredArgsConstructor
public class ProfileController {

    private final UserService userService;
    private final ProfileService profileService;
    private final PostRepository postRepository;

    @GetMapping("/profile")
    public String ownProfile(@AuthenticationPrincipal User currentUser, Model model) {
        populateModel(model, currentUser, currentUser);
        model.addAttribute("isOwnProfile", true);
        if (!model.containsAttribute("profileUpdateDto")) {
            ProfileUpdateDto dto = new ProfileUpdateDto();
            dto.setFirstName(currentUser.getFirstName());
            dto.setLastName(currentUser.getLastName());
            dto.setBio(currentUser.getBio());
            model.addAttribute("profileUpdateDto", dto);
        }
        return "profile";
    }

    @GetMapping("/profile/{userId}")
    public String viewProfile(@PathVariable Long userId,
                              @AuthenticationPrincipal User currentUser,
                              Model model) {
        if (currentUser.getId().equals(userId)) {
            return "redirect:/profile";
        }
        User profileUser = userService.getById(userId);
        populateModel(model, profileUser, currentUser);
        model.addAttribute("isOwnProfile", false);
        return "profile";
    }

    @PostMapping("/profile")
    public String updateProfile(@AuthenticationPrincipal User currentUser,
                                 @Valid @ModelAttribute("profileUpdateDto") ProfileUpdateDto dto,
                                 BindingResult bindingResult,
                                 Model model) {
        if (bindingResult.hasErrors()) {
            populateModel(model, currentUser, currentUser);
            model.addAttribute("isOwnProfile", true);
            return "profile";
        }
        profileService.updateProfile(currentUser, dto);
        return "redirect:/profile?updated=true";
    }

    private void populateModel(Model model, User profileUser, User currentUser) {
        model.addAttribute("profileUser", profileUser);
        model.addAttribute("postCount", profileService.getPostCount(profileUser.getId()));
        model.addAttribute("friendCount", profileService.getFriendCount(profileUser.getId()));
        model.addAttribute("recentPosts",
                postRepository.findByAuthorIdOrderByCreatedAtDesc(profileUser.getId()));
        model.addAttribute("currentUser", currentUser);
    }
}
