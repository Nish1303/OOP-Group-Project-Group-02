package com.kln.socialapp.entity;

public enum FriendRequestStatus {
    PENDING,
    ACCEPTED,
    DECLINED
}
