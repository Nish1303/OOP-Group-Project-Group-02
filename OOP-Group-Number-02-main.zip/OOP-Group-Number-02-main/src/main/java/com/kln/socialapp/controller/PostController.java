package com.kln.socialapp.controller;

import com.kln.socialapp.dto.CommentDto;
import com.kln.socialapp.entity.Post;
import com.kln.socialapp.entity.User;
import com.kln.socialapp.repository.PostRepository;
import com.kln.socialapp.service.CommentService;
import com.kln.socialapp.service.LikeService;
import com.kln.socialapp.repository.PostLikeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Renders the single-post detail view, which includes
 * the full comment thread for that post.
 */
@Controller
@RequiredArgsConstructor
public class PostController {

    private final PostRepository postRepository;
    private final CommentService commentService;
    private final PostLikeRepository postLikeRepository;

    @GetMapping("/posts/{postId}")
    public String postDetail(@PathVariable Long postId,
                             @AuthenticationPrincipal User currentUser,
                             Model model) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new IllegalArgumentException("Post not found: " + postId));

        long likeCount = postLikeRepository.countByPostId(postId);
        boolean liked = postLikeRepository.existsByPostIdAndUserId(postId, currentUser.getId());

        model.addAttribute("post", post);
        model.addAttribute("likeCount", likeCount);
        model.addAttribute("likedByCurrentUser", liked);
        model.addAttribute("comments", commentService.getCommentsForPost(postId));
        model.addAttribute("commentDto", new CommentDto());
        model.addAttribute("currentUser", currentUser);
        return "post-detail";
    }
}
