package com.kln.socialapp.repository;

import com.kln.socialapp.entity.Post;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PostRepository extends JpaRepository<Post, Long> {

    // Feed = own posts + posts from accepted friends, newest first
    @Query("SELECT p FROM Post p WHERE p.author.id = :userId OR p.author.id IN :friendIds " +
           "ORDER BY p.createdAt DESC")
    List<Post> findFeedForUser(@Param("userId") Long userId, @Param("friendIds") List<Long> friendIds);

    List<Post> findByAuthorIdOrderByCreatedAtDesc(Long authorId);

    long countByAuthorId(Long authorId);
}
