package com.kln.socialapp.controller;

import com.kln.socialapp.dto.CommentDto;
import com.kln.socialapp.entity.User;
import com.kln.socialapp.service.CommentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

/**
 * Handles comment creation and deletion for the optional Comment System feature.
 * Submits redirect back to the post detail view.
 */
@Controller
@RequiredArgsConstructor
public class CommentController {

    private final CommentService commentService;

    @PostMapping("/posts/{postId}/comments")
    public String addComment(@AuthenticationPrincipal User currentUser,
                             @PathVariable Long postId,
                             @Valid @ModelAttribute CommentDto commentDto,
                             BindingResult bindingResult) {
        if (!bindingResult.hasErrors()) {
            commentDto.setPostId(postId);
            commentService.addComment(currentUser, commentDto);
        }
        return "redirect:/posts/" + postId;
    }

    @PostMapping("/comments/{commentId}/delete")
    public String deleteComment(@AuthenticationPrincipal User currentUser,
                                @PathVariable Long commentId,
                                @RequestParam Long postId) {
        commentService.deleteComment(commentId, currentUser);
        return "redirect:/posts/" + postId;
    }
}
