package com.kln.socialapp.service;

import com.kln.socialapp.entity.FriendRequest;
import com.kln.socialapp.entity.FriendRequestStatus;
import com.kln.socialapp.entity.User;
import com.kln.socialapp.exception.FriendRequestException;
import com.kln.socialapp.repository.FriendRequestRepository;
import com.kln.socialapp.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Business logic for the friend request / friendship system.
 */
@Service
@RequiredArgsConstructor
public class FriendService {

    private final FriendRequestRepository friendRequestRepository;
    private final UserRepository userRepository;

    @Transactional
    public FriendRequest sendRequest(User sender, Long receiverId) {
        if (sender.getId().equals(receiverId)) {
            throw new FriendRequestException("You cannot send a friend request to yourself.");
        }

        User receiver = userRepository.findById(receiverId)
                .orElseThrow(() -> new IllegalArgumentException("User not found: " + receiverId));

        var existing = friendRequestRepository.findBetweenUsers(sender.getId(), receiverId);
        if (existing.isPresent()) {
            FriendRequest fr = existing.get();
            switch (fr.getStatus()) {
                case PENDING -> throw new FriendRequestException("A friend request already exists between you two.");
                case ACCEPTED -> throw new FriendRequestException("You are already friends with this user.");
                case DECLINED -> {
                    // Allow re-sending after a decline by resetting the existing record
                    fr.setSender(sender);
                    fr.setReceiver(receiver);
                    fr.setStatus(FriendRequestStatus.PENDING);
                    fr.setCreatedAt(LocalDateTime.now());
                    fr.setRespondedAt(null);
                    return friendRequestRepository.save(fr);
                }
            }
        }

        FriendRequest request = FriendRequest.builder()
                .sender(sender)
                .receiver(receiver)
                .status(FriendRequestStatus.PENDING)
                .build();
        return friendRequestRepository.save(request);
    }

    @Transactional
    public void respondToRequest(Long requestId, User currentUser, boolean accept) {
        FriendRequest request = friendRequestRepository.findById(requestId)
                .orElseThrow(() -> new IllegalArgumentException("Friend request not found: " + requestId));

        if (!request.getReceiver().getId().equals(currentUser.getId())) {
            throw new FriendRequestException("You are not authorised to respond to this request.");
        }

        if (request.getStatus() != FriendRequestStatus.PENDING) {
            throw new FriendRequestException("This request has already been responded to.");
        }

        request.setStatus(accept ? FriendRequestStatus.ACCEPTED : FriendRequestStatus.DECLINED);
        request.setRespondedAt(LocalDateTime.now());
        friendRequestRepository.save(request);
    }

    public List<FriendRequest> getIncomingRequests(Long userId) {
        return friendRequestRepository.findByReceiverIdAndStatus(userId, FriendRequestStatus.PENDING);
    }

    public List<FriendRequest> getOutgoingRequests(Long userId) {
        return friendRequestRepository.findBySenderIdAndStatus(userId, FriendRequestStatus.PENDING);
    }

    public List<FriendRequest> getFriends(Long userId) {
        return friendRequestRepository.findAcceptedFriendshipsForUser(userId);
    }

    public boolean areFriends(Long userId1, Long userId2) {
        return friendRequestRepository.areFriends(userId1, userId2);
    }

    /**
     * Returns the relationship status between current user and another user,
     * used by the directory page to decide which button to show
     * (Add Friend / Pending / Friends).
     */
    public String getRelationshipStatus(Long currentUserId, Long otherUserId) {
        var existing = friendRequestRepository.findBetweenUsers(currentUserId, otherUserId);
        if (existing.isEmpty()) {
            return "NONE";
        }
        FriendRequest fr = existing.get();
        if (fr.getStatus() == FriendRequestStatus.ACCEPTED) {
            return "FRIENDS";
        }
        if (fr.getStatus() == FriendRequestStatus.PENDING) {
            return fr.getSender().getId().equals(currentUserId) ? "REQUEST_SENT" : "REQUEST_RECEIVED";
        }
        return "NONE"; // declined -> can send again
    }
}
