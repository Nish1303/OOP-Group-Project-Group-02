package com.kln.socialapp.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "friend_requests", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"sender_id", "receiver_id"})
})
public class FriendRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "sender_id", nullable = false)
    private User sender;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "receiver_id", nullable = false)
    private User receiver;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private FriendRequestStatus status = FriendRequestStatus.PENDING;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "responded_at")
    private LocalDateTime respondedAt;

    public FriendRequest() {}

    // Builder
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private final FriendRequest fr = new FriendRequest();
        public Builder sender(User v)   { fr.sender = v; return this; }
        public Builder receiver(User v) { fr.receiver = v; return this; }
        public Builder status(FriendRequestStatus v) { fr.status = v; return this; }
        public FriendRequest build() { return fr; }
    }

    public Long getId()                   { return id; }
    public User getSender()               { return sender; }
    public void setSender(User v)         { this.sender = v; }
    public User getReceiver()             { return receiver; }
    public void setReceiver(User v)       { this.receiver = v; }
    public FriendRequestStatus getStatus(){ return status; }
    public void setStatus(FriendRequestStatus v) { this.status = v; }
    public LocalDateTime getCreatedAt()   { return createdAt; }
    public void setCreatedAt(LocalDateTime v)    { this.createdAt = v; }
    public LocalDateTime getRespondedAt() { return respondedAt; }
    public void setRespondedAt(LocalDateTime v)  { this.respondedAt = v; }
}
