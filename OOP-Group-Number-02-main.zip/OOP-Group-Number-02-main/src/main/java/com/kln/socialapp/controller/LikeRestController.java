package com.kln.socialapp.controller;

import com.kln.socialapp.entity.User;
import com.kln.socialapp.service.LikeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * REST endpoint backing the dynamic (AJAX/fetch) like/unlike toggle on posts.
 * No full page reload is triggered; the client updates the DOM from the JSON response.
 */
@RestController
@RequiredArgsConstructor
public class LikeRestController {

    private final LikeService likeService;

    @PostMapping("/api/posts/{postId}/like")
    public ResponseEntity<Map<String, Object>> toggleLike(@AuthenticationPrincipal User currentUser,
                                                            @PathVariable Long postId) {
        try {
            LikeService.LikeResult result = likeService.toggleLike(postId, currentUser);
            Map<String, Object> response = new HashMap<>();
            response.put("liked", result.liked);
            response.put("likeCount", result.likeCount);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException ex) {
            Map<String, Object> error = new HashMap<>();
            error.put("error", ex.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        } catch (Exception ex) {
            Map<String, Object> error = new HashMap<>();
            error.put("error", "Could not process like. Please try again.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }
}
