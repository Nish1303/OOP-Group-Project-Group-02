package com.kln.socialapp.service;

import com.kln.socialapp.entity.Post;
import com.kln.socialapp.entity.PostLike;
import com.kln.socialapp.entity.User;
import com.kln.socialapp.repository.PostLikeRepository;
import com.kln.socialapp.repository.PostRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class LikeService {

    private final PostLikeRepository postLikeRepository;
    private final PostRepository postRepository;

    public static class LikeResult {
        public final boolean liked;
        public final long likeCount;

        public LikeResult(boolean liked, long likeCount) {
            this.liked = liked;
            this.likeCount = likeCount;
        }
    }

    @Transactional
    public LikeResult toggleLike(Long postId, User user) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new IllegalArgumentException("Post not found: " + postId));

        var existing = postLikeRepository.findByPostIdAndUserId(postId, user.getId());

        boolean nowLiked;
        if (existing.isPresent()) {
            postLikeRepository.delete(existing.get());
            nowLiked = false;
        } else {
            PostLike like = new PostLike(post, user);
            postLikeRepository.save(like);
            nowLiked = true;
        }

        long count = postLikeRepository.countByPostId(postId);
        return new LikeResult(nowLiked, count);
    }
}
