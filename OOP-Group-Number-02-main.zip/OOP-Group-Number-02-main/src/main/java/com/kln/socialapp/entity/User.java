package com.kln.socialapp.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;

/**
 * Represents an application user / account.
 * Implements UserDetails so Spring Security can use it directly.
 *
 * Note: written without Lombok on purpose so the UserDetails method
 * signatures (especially getPassword / getUsername) are unambiguous.
 */
@Entity
@Table(name = "users")
public class User implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Email
    @Column(unique = true, nullable = false)
    private String email;

    @NotBlank
    @Column(name = "first_name", nullable = false)
    private String firstName;

    @NotBlank
    @Column(name = "last_name", nullable = false)
    private String lastName;

    @NotBlank
    @Column(nullable = false)
    private String password; // BCrypt-hashed

    @Column(name = "role", nullable = false)
    private String role = "ROLE_USER";

    @Column(name = "enabled", nullable = false)
    private boolean enabled = true;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "bio", length = 500)
    private String bio;

    // ---- Constructors ----

    public User() {}

    // Builder-style static factory used by DataInitializer and UserService
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private final User u = new User();
        public Builder email(String v)     { u.email = v; return this; }
        public Builder firstName(String v) { u.firstName = v; return this; }
        public Builder lastName(String v)  { u.lastName = v; return this; }
        public Builder password(String v)  { u.password = v; return this; }
        public Builder role(String v)      { u.role = v; return this; }
        public Builder enabled(boolean v)  { u.enabled = v; return this; }
        public Builder bio(String v)       { u.bio = v; return this; }
        public User build() {
            if (u.createdAt == null) u.createdAt = LocalDateTime.now();
            return u;
        }
    }

    // ---- Getters ----

    public Long getId()            { return id; }
    public String getEmail()       { return email; }
    public String getFirstName()   { return firstName; }
    public String getLastName()    { return lastName; }
    public String getRole()        { return role; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public String getBio()         { return bio; }

    public String getFullName()    { return firstName + " " + lastName; }

    // ---- Setters ----

    public void setId(Long id)               { this.id = id; }
    public void setEmail(String email)       { this.email = email; }
    public void setFirstName(String v)       { this.firstName = v; }
    public void setLastName(String v)        { this.lastName = v; }
    public void setPassword(String v)        { this.password = v; }
    public void setRole(String v)            { this.role = v; }
    public void setEnabled(boolean v)        { this.enabled = v; }
    public void setCreatedAt(LocalDateTime v){ this.createdAt = v; }
    public void setBio(String v)             { this.bio = v; }

    // ---- UserDetails implementation ----

    @Override public String getPassword()  { return password; }
    @Override public String getUsername()  { return email; }   // auth by email

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Collections.singletonList(new SimpleGrantedAuthority(role));
    }

    @Override public boolean isAccountNonExpired()   { return true; }
    @Override public boolean isAccountNonLocked()    { return true; }
    @Override public boolean isCredentialsNonExpired(){ return true; }
    @Override public boolean isEnabled()             { return enabled; }
}
