package com.kln.socialapp.service;

import com.kln.socialapp.entity.User;
import com.kln.socialapp.repository.PostRepository;
import com.kln.socialapp.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Business logic for the optional Admin Role & Dashboard feature (10%).
 * Role-based access is enforced via Spring Security in SecurityConfig (.hasRole("ADMIN")).
 */
@Service
@RequiredArgsConstructor
public class AdminService {

    private final UserRepository userRepository;
    private final PostRepository postRepository;

    public Page<User> getAllUsers(int page, int size) {
        return userRepository.findAll(PageRequest.of(page, size));
    }

    @Transactional
    public void toggleUserEnabled(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found: " + userId));
        if (user.getRole().equals("ROLE_ADMIN")) {
            throw new IllegalArgumentException("Cannot deactivate an admin account.");
        }
        user.setEnabled(!user.isEnabled());
        userRepository.save(user);
    }

    @Transactional
    public void deletePost(Long postId) {
        if (!postRepository.existsById(postId)) {
            throw new IllegalArgumentException("Post not found: " + postId);
        }
        postRepository.deleteById(postId);
    }

    public long countUsers() {
        return userRepository.count();
    }

    public long countPosts() {
        return postRepository.count();
    }
}
