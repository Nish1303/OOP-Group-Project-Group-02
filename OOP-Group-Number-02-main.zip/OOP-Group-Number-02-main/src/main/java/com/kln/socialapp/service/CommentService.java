package com.kln.socialapp.service;

import com.kln.socialapp.dto.CommentDto;
import com.kln.socialapp.entity.Comment;
import com.kln.socialapp.entity.Post;
import com.kln.socialapp.entity.User;
import com.kln.socialapp.exception.FriendRequestException;
import com.kln.socialapp.repository.CommentRepository;
import com.kln.socialapp.repository.PostRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CommentService {

    private final CommentRepository commentRepository;
    private final PostRepository postRepository;

    @Transactional
    public Comment addComment(User author, CommentDto dto) {
        Post post = postRepository.findById(dto.getPostId())
                .orElseThrow(() -> new IllegalArgumentException("Post not found: " + dto.getPostId()));

        Comment comment = new Comment();
        comment.setPost(post);
        comment.setAuthor(author);
        comment.setContent(dto.getContent().trim());
        return commentRepository.save(comment);
    }

    @Transactional
    public void deleteComment(Long commentId, User currentUser) {
        Comment comment = commentRepository.findByIdAndAuthorId(commentId, currentUser.getId())
                .orElseThrow(() -> new FriendRequestException("You can only delete your own comments."));
        commentRepository.delete(comment);
    }

    public List<Comment> getCommentsForPost(Long postId) {
        return commentRepository.findByPostIdOrderByCreatedAtAsc(postId);
    }

    public long countForPost(Long postId) {
        return commentRepository.countByPostId(postId);
    }
}
