package com.kln.socialapp.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class CommentDto {

    @NotBlank(message = "Comment cannot be empty")
    @Size(max = 1000, message = "Comment must not exceed 1000 characters")
    private String content;

    private Long postId;

    public String getContent()       { return content; }
    public void setContent(String v) { this.content = v; }
    public Long getPostId()          { return postId; }
    public void setPostId(Long v)    { this.postId = v; }
}
