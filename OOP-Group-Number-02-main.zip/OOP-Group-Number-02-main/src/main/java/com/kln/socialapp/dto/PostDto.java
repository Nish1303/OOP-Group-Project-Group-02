package com.kln.socialapp.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class PostDto {

    @NotBlank(message = "Post content cannot be empty")
    @Size(max = 2000, message = "Post content must not exceed 2000 characters")
    private String content;

    public String getContent()       { return content; }
    public void setContent(String v) { this.content = v; }
}
