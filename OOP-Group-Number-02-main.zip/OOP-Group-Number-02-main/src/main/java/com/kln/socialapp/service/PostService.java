package com.kln.socialapp.service;

import com.kln.socialapp.dto.PostDto;
import com.kln.socialapp.dto.PostView;
import com.kln.socialapp.entity.FriendRequest;
import com.kln.socialapp.entity.Post;
import com.kln.socialapp.entity.User;
import com.kln.socialapp.repository.FriendRequestRepository;
import com.kln.socialapp.repository.PostLikeRepository;
import com.kln.socialapp.repository.PostRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * Business logic for posts: creation and feed assembly.
 */
@Service
@RequiredArgsConstructor
public class PostService {

    private final PostRepository postRepository;
    private final PostLikeRepository postLikeRepository;
    private final FriendRequestRepository friendRequestRepository;

    @Transactional
    public Post createPost(User author, PostDto dto) {
        Post post = new Post();
        post.setAuthor(author);
        post.setContent(dto.getContent().trim());
        return postRepository.save(post);
    }

    /**
     * Builds the home feed: the user's own posts merged with their friends' posts,
     * sorted newest first, with like-count and "liked by me" info attached.
     */
    public List<PostView> getFeedForUser(User currentUser) {
        List<Long> friendIds = getFriendIds(currentUser.getId());
        List<Post> posts;
        if (friendIds.isEmpty()) {
            // Avoid JPQL "IN ()" crash when user has no friends yet
            posts = postRepository.findByAuthorIdOrderByCreatedAtDesc(currentUser.getId());
        } else {
            posts = postRepository.findFeedForUser(currentUser.getId(), friendIds);
        }

        List<PostView> views = new ArrayList<>();
        for (Post post : posts) {
            views.add(toPostView(post, currentUser.getId()));
        }
        return views;
    }

    public List<Long> getFriendIds(Long userId) {
        List<FriendRequest> accepted = friendRequestRepository.findAcceptedFriendshipsForUser(userId);
        List<Long> ids = new ArrayList<>();
        for (FriendRequest fr : accepted) {
            if (fr.getSender().getId().equals(userId)) {
                ids.add(fr.getReceiver().getId());
            } else {
                ids.add(fr.getSender().getId());
            }
        }
        return ids;
    }

    private PostView toPostView(Post post, Long currentUserId) {
        long likeCount = postLikeRepository.countByPostId(post.getId());
        boolean likedByCurrentUser = postLikeRepository.existsByPostIdAndUserId(post.getId(), currentUserId);
        return new PostView(
                post.getId(),
                post.getAuthor().getFullName(),
                post.getAuthor().getId(),
                post.getContent(),
                post.getCreatedAt(),
                likeCount,
                likedByCurrentUser
        );
    }
}
