package com.kln.socialapp.service;

import com.kln.socialapp.dto.ProfileUpdateDto;
import com.kln.socialapp.entity.User;
import com.kln.socialapp.repository.PostRepository;
import com.kln.socialapp.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ProfileService {

    private final UserRepository userRepository;
    private final PostRepository postRepository;
    private final FriendService friendService;

    public long getPostCount(Long userId) {
        return postRepository.countByAuthorId(userId);
    }

    public long getFriendCount(Long userId) {
        return friendService.getFriends(userId).size();
    }

    @Transactional
    public User updateProfile(User currentUser, ProfileUpdateDto dto) {
        currentUser.setFirstName(dto.getFirstName().trim());
        currentUser.setLastName(dto.getLastName().trim());
        currentUser.setBio(dto.getBio() != null ? dto.getBio().trim() : null);
        return userRepository.save(currentUser);
    }
}
