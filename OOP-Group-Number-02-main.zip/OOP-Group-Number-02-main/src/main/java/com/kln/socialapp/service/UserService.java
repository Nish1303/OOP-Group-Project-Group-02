package com.kln.socialapp.service;

import com.kln.socialapp.dto.RegistrationDto;
import com.kln.socialapp.entity.User;
import com.kln.socialapp.exception.DuplicateEmailException;
import com.kln.socialapp.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Transactional
    public User register(RegistrationDto dto) {
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new DuplicateEmailException("An account with this email already exists.");
        }

        User user = User.builder()
                .email(dto.getEmail().toLowerCase().trim())
                .firstName(dto.getFirstName().trim())
                .lastName(dto.getLastName().trim())
                .password(passwordEncoder.encode(dto.getPassword()))
                .role("ROLE_USER")
                .enabled(true)
                .build();

        return userRepository.save(user);
    }

    public User getById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found: " + id));
    }

    public User getByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("User not found: " + email));
    }

    public Page<User> getDirectory(Long currentUserId, int page, int size) {
        return userRepository.findByIdNot(currentUserId, PageRequest.of(page, size));
    }

    public Page<User> searchUsers(Long currentUserId, String keyword, int page, int size) {
        return userRepository.searchByNameOrEmail(currentUserId, keyword, PageRequest.of(page, size));
    }
}
