package com.kln.socialapp.config;

import com.kln.socialapp.entity.User;
import com.kln.socialapp.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Seeds the database with a default admin account on first startup if none exists.
 *
 * Admin credentials (change after first login):
 *   Email:    admin@socialapp.local
 *   Password: Admin@1234
 */
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (userRepository.existsByEmail("admin@socialapp.local")) {
            return;
        }

        User admin = User.builder()
                .email("admin@socialapp.local")
                .firstName("Admin")
                .lastName("User")
                .password(passwordEncoder.encode("Admin@1234"))
                .role("ROLE_ADMIN")
                .enabled(true)
                .build();

        userRepository.save(admin);
        System.out.println(">>> Default admin account created: admin@socialapp.local / Admin@1234 — please change the password!");
    }
}
