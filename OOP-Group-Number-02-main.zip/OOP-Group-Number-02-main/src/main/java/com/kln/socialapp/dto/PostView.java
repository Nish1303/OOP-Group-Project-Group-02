package com.kln.socialapp.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * Read-only view model for rendering a post in the feed.
 * Wraps entity data plus computed fields (like count, whether current user liked it)
 * so the Thymeleaf templates don't need to call back into services.
 */
@Getter
@Setter
@AllArgsConstructor
public class PostView {
    private Long id;
    private String authorName;
    private Long authorId;
    private String content;
    private LocalDateTime createdAt;
    private long likeCount;
    private boolean likedByCurrentUser;
}
