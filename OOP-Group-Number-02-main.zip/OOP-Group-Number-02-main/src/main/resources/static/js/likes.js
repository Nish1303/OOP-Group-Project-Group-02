async function toggleLike(postId) {
    try {
        const response = await fetch(`/api/posts/${postId}/like`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });

        if (!response.ok) {
            console.error('Failed to toggle like');
            return;
        }

        const data = await response.json();
        const postEl = document.getElementById(`post-${postId}`);
        const btn = postEl.querySelector('.like-btn');
        const icon = postEl.querySelector('.like-icon');
        const countEl = postEl.querySelector('.like-count');

        countEl.textContent = data.likeCount;

        if (data.liked) {
            btn.classList.add('liked');
            icon.textContent = '♥';
        } else {
            btn.classList.remove('liked');
            icon.textContent = '♡';
        }
    } catch (err) {
        console.error('Error toggling like:', err);
    }
}
