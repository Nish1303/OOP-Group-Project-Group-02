# CSCI 22082 – Spring Boot Social Media Application
**University of Kelaniya | Academic Year 2024/2025 – Semester II**

## Technology Stack
| Layer | Technology |
|---|---|
| Backend Framework | Spring Boot 3.2 |
| Persistence | Spring Data JPA + MySQL |
| Security | Spring Security (BCrypt, session-based auth) |
| Frontend | Thymeleaf + vanilla CSS + `fetch()` for AJAX |
| Build | Maven |

---

## Prerequisites
- Java 17+
- Maven 3.9+
- MySQL 8+ running locally

---

## Setup & Run

### 1. Create the database
```sql
CREATE DATABASE socialapp_db;
```

### 2. Configure credentials
Edit `src/main/resources/application.properties`:
```properties
spring.datasource.username=root
spring.datasource.password=your_mysql_password
```

### 3. Build & run
```bash
cd socialapp
mvn spring-boot:run
```

The application starts at **http://localhost:8080**.

Hibernate will auto-create all tables on the first run (`ddl-auto=update`).

### 4. Default admin account
On first startup a seed admin account is created:

| Field | Value |
|---|---|
| Email | admin@socialapp.local |
| Password | Admin@1234 |

> **Change this password immediately after your first login.**

---

## Features Implemented

### Mandatory (60%)
| # | Feature | Status |
|---|---|---|
| 1 | Landing Page, Registration & Authentication | ✅ |
| 2 | Home Feed & Post Creation | ✅ |
| 3 | Session Management & Logout | ✅ |
| 4 | Friend Management System (send/accept/decline, directory) | ✅ |
| 5 | Like / Unlike (AJAX – no page reload) | ✅ |

### Optional (up to 20%)
| Feature | Marks | Status |
|---|---|---|
| User Profile Page (view + edit, bio, join date, post/friend count) | 5% | ✅ |
| Comment System (add, view, delete own) | 5% | ✅ |
| Search (users by name/email in directory) | 5% | ✅ |
| Admin Role & Dashboard (toggle users, role-based access) | 10% | ✅ |

---

## Project Structure
```
src/main/java/com/kln/socialapp/
├── SocialAppApplication.java
├── config/
│   ├── DataInitializer.java     # Seeds admin account
│   └── SecurityConfig.java      # Spring Security rules
├── controller/
│   ├── AuthController.java      # /login  /register
│   ├── FeedController.java      # /feed   /posts
│   ├── PostController.java      # /posts/{id}  (detail + comments)
│   ├── CommentController.java   # /posts/{id}/comments  /comments/{id}/delete
│   ├── FriendController.java    # /directory  /friends  /friends/request/*
│   ├── ProfileController.java   # /profile  /profile/{id}
│   ├── LikeRestController.java  # /api/posts/{id}/like  (REST/AJAX)
│   └── AdminController.java     # /admin/**
├── dto/           # Input/output data transfer objects
├── entity/        # JPA entities: User, Post, PostLike, Comment, FriendRequest
├── exception/     # Custom exceptions + GlobalExceptionHandler
├── repository/    # Spring Data JPA repositories
├── security/      # CustomUserDetailsService
└── service/       # Business logic layer (UserService, PostService, etc.)
```

---

## GitHub Workflow (team guide)
- `main` — always stable; only merged via Pull Request
- Feature branches: `feature/login`, `feature/friend-requests`, `feature/comments`, etc.
- Commit messages: descriptive (`Add BCrypt hashing to UserService`, not `fix stuff`)
- Every team member must have visible individual commits
